import { useState } from 'react';
import '../styles/home.css';

export default function Home() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    message: ''
  });
  const [sliderPosition, setSliderPosition] = useState(50);
  const [activeFilter, setActiveFilter] = useState('todos');

  const rodillos = [
    { id: 1, src: '/rodillos/Foto1.jpeg', alt: 'Rouleau personnalisé 1' },
    { id: 2, src: '/rodillos/Foto2.jpeg', alt: 'Rouleau personnalisé 2' },
    { id: 3, src: '/rodillos/Foto3.jpeg', alt: 'Rouleau personnalisé 3' },
    { id: 4, src: '/rodillos/Foto4.jpeg', alt: 'Rouleau personnalisé 4' },
    { id: 5, src: '/rodillos/Foto5.jpeg', alt: 'Rouleau personnalisé 5' },
    { id: 6, src: '/rodillos/Foto6.jpeg', alt: 'Rouleau personnalisé 6' },
    { id: 7, src: '/rodillos/Foto7.jpeg', alt: 'Rouleau personnalisé 7' },
    { id: 8, src: '/rodillos/Foto8.jpeg', alt: 'Rouleau personnalisé 8' },
    { id: 9, src: '/rodillos/Foto9.jpeg', alt: 'Rouleau personnalisé 9' },
    { id: 10, src: '/rodillos/Foto10.jpeg', alt: 'Rouleau personnalisé 10' },
    { id: 11, src: '/rodillos/Foto11.jpeg', alt: 'Rouleau personnalisé 11' },
  ];

  const handleFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleFormSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    console.log('Formulaire envoyé:', formData);
    alert('Merci pour votre message ! Nous vous contacterons bientôt.');
    setFormData({ name: '', email: '', company: '', message: '' });
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const container = e.currentTarget;
    const rect = container.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const percentage = (x / rect.width) * 100;
    setSliderPosition(Math.max(0, Math.min(100, percentage)));
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    const container = e.currentTarget;
    const rect = container.getBoundingClientRect();
    const x = e.touches[0].clientX - rect.left;
    const percentage = (x / rect.width) * 100;
    setSliderPosition(Math.max(0, Math.min(100, percentage)));
  };

  return (
    <div className="filete3d-landing">
      {/* Navbar */}
      <nav className="navbar navbar-expand-lg navbar-light">
        <div className="container-fluid px-4">
          <a className="navbar-brand" href="#home">
            <img src="/logotipo.png" alt="Filete 3D" />
            <span>Filete 3D</span>
          </a>
          <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav ms-auto">
              <li className="nav-item">
                <a className="nav-link" href="#proposition">Proposition</a>
              </li>
              <li className="nav-item">
                <a className="nav-link" href="#processus">Processus</a>
              </li>
              <li className="nav-item">
                <a className="nav-link" href="#avantages">Avantages</a>
              </li>
              <li className="nav-item">
                <a className="nav-link" href="#innovation">Innovation</a>
              </li>
              <li className="nav-item">
                <a className="nav-link" href="#rouleaux">Rouleaux</a>
              </li>
              <li className="nav-item">
                <a className="nav-link" href="#contact">Contact</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="hero" id="home">
        <div className="container-fluid">
          <div className="row align-items-center">
            <div className="col-lg-6 hero-content">
              <h1>Le pont entre la porcelaine artisanale et l'ingénierie numérique</h1>
              <p>Des moules imprimés en 3D qui respectent la tradition de Limoges et repoussent ses limites techniques et esthétiques.</p>
              <div className="d-flex gap-3 flex-wrap">
                <a href="#contact" className="btn btn-primary">Demander une réunion technique</a>
                <a href="#proposition" className="btn btn-outline">En savoir plus</a>
              </div>
            </div>
            <div className="col-lg-6 hero-image">
              <img src="/hero-3d-printing.jpg" alt="Impression 3D de moules" className="img-fluid" />
            </div>
          </div>
        </div>
      </section>

      {/* Sección: Notre Proposition */}
      <section className="bg-light" id="proposition">
        <div className="container-fluid px-4">
          <div className="section-title">
            <h2>De l'art du moule à la précision numérique</h2>
          </div>
          <div className="row align-items-center">
            <div className="col-lg-6">
              <img src="/porcelain-mold-process.jpg" alt="Processus de moules de porcelaine" className="img-fluid rounded" />
            </div>
            <div className="col-lg-6 ps-lg-4">
              <p>
                Chez <strong>Filete 3D</strong>, nous accompagnons les ateliers et les manufactures de porcelaine dans leur transition vers la fabrication avancée. Nous combinons la sensibilité artisanale du modelage traditionnel avec les outils d'ingénierie 3D pour créer des moules reproductibles, précis et fidèles à l'esprit de Limoges.
              </p>
              <p>
                Notre mission : préserver l'âme de la porcelaine, tout en l'ouvrant à un avenir numérique, durable et compétitif.
              </p>
              <ul className="list-unstyled mt-4">
                <li className="mb-3">
                  <i className="fas fa-check text-copper me-2"></i>
                  <strong>Précision technique</strong> garantie sur chaque moule
                </li>
                <li className="mb-3">
                  <i className="fas fa-check text-copper me-2"></i>
                  <strong>Agilité créative</strong> dans la conception et l'adaptation
                </li>
                <li className="mb-3">
                  <i className="fas fa-check text-copper me-2"></i>
                  <strong>Respect du savoir-faire</strong> de Limoges
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Sección: Comment Nous Travaillons */}
      <section id="processus">
        <div className="container-fluid px-4">
          <div className="section-title">
            <h2>De votre idée au moule parfait : un processus transparent et collaboratif</h2>
          </div>
          <div className="row">
            <div className="col-lg-6">
              <div className="process-step" data-step="1">
                <h4>Conception CAO</h4>
                <p>Nous transformons vos modèles physiques ou croquis en géométries numériques précises.</p>
              </div>
              <div className="process-step" data-step="2">
                <h4>Optimisation technique</h4>
                <p>Adaptation du modèle aux contraintes de coulage et de cuisson.</p>
              </div>
              <div className="process-step" data-step="3">
                <h4>Impression 3D du moule</h4>
                <p>Utilisation de matériaux calibrés pour la résistance à l'humidité et à la pression.</p>
              </div>
            </div>
            <div className="col-lg-6">
              <div className="process-step" data-step="4">
                <h4>Finition manuelle</h4>
                <p>Ponçage, scellement et contrôle dimensionnel.</p>
              </div>
              <div className="process-step" data-step="5">
                <h4>Validation en atelier</h4>
                <p>Nos moules sont testés et approuvés par des céramistes de Limoges.</p>
              </div>
              <div className="bg-light p-4 rounded mt-4">
                <h5 className="text-primary mb-3">Cas de Succès</h5>
                <p className="mb-2">
                  <strong>Moule 3D validé et utilisé dans la collection Éclat d'Atelier de Jérémy Asmont</strong>
                </p>
                <p className="text-muted small">Approuvé par les céramistes locaux avec d'excellents résultats de production.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Sección: Pourquoi Nous Choisir */}
      <section className="bg-light" id="avantages">
        <div className="container-fluid px-4">
          <div className="section-title">
            <h2>Pourquoi les fabricants nous choisissent</h2>
            <p className="text-muted">Précision technique, agilité créative et respect du savoir-faire de Limoges</p>
          </div>
          <div className="row g-4">
            <div className="col-md-6 col-lg-4">
              <div className="feature-card">
                <div className="feature-card-icon">
                  <i className="fas fa-bolt"></i>
                </div>
                <h4>Réduction du Temps</h4>
                <p>Réduction du temps de développement des moules jusqu'à 60%.</p>
              </div>
            </div>
            <div className="col-md-6 col-lg-4">
              <div className="feature-card">
                <div className="feature-card-icon">
                  <i className="fas fa-ruler"></i>
                </div>
                <h4>Contrôle Numérique</h4>
                <p>Contrôle numérique des géométries et des ajustements.</p>
              </div>
            </div>
            <div className="col-md-6 col-lg-4">
              <div className="feature-card">
                <div className="feature-card-icon">
                  <i className="fas fa-sync"></i>
                </div>
                <h4>Répétabilité</h4>
                <p>Répétabilité sans perte de qualité esthétique.</p>
              </div>
            </div>
            <div className="col-md-6 col-lg-4">
              <div className="feature-card">
                <div className="feature-card-icon">
                  <i className="fas fa-headset"></i>
                </div>
                <h4>Accompagnement Personnalisé</h4>
                <p>Assistance à chaque étape du processus.</p>
              </div>
            </div>
            <div className="col-md-6 col-lg-4">
              <div className="feature-card">
                <div className="feature-card-icon">
                  <i className="fas fa-leaf"></i>
                </div>
                <h4>Durabilité</h4>
                <p>Production locale, collaborative et durable.</p>
              </div>
            </div>
            <div className="col-md-6 col-lg-4">
              <div className="feature-card">
                <div className="feature-card-icon">
                  <i className="fas fa-check-circle"></i>
                </div>
                <h4>Garantie de Qualité</h4>
                <p>Vérification dimensionnelle et tests de coulage.</p>
              </div>
            </div>
          </div>
          <div className="text-center mt-5">
            <a href="#contact" className="btn btn-secondary">Évaluer un moule 3D pour ma prochaine collection</a>
          </div>
        </div>
      </section>

      {/* Sección: Innovation - NFT & Gemelo Digital */}
      <section id="innovation">
        <div className="container-fluid px-4">
          <div className="section-title">
            <h2>Innovation et Avenir : NFT & Contrats Intelligents</h2>
          </div>
          
          {/* Comparaison Porcelaine Traditionnelle vs Digital con efecto antes y después */}
          <div className="row justify-content-center mb-5">
            <div className="col-lg-8">
              <h4 className="text-center mb-4" style={{color: '#00D9FF', fontSize: '1.5rem', textShadow: '0 0 10px rgba(0, 217, 255, 0.3)'}}>Jumeau Numérique Futuriste</h4>
              <div 
                className="comparison-slider"
                onMouseMove={handleMouseMove}
                onTouchMove={handleTouchMove}
                onMouseLeave={() => setSliderPosition(50)}
              >
                <div className="comparison-container">
                  {/* Imagen de fondo - Jarrón tradicional */}
                  <img 
                    src="/jarron-porcelaine.png" 
                    alt="Porcelaine traditionnelle" 
                    className="comparison-image comparison-image-before"
                  />
                  
                  {/* Imagen superpuesta - Gemelo digital */}
                  <div 
                    className="comparison-image-overlay"
                    style={{ clipPath: `inset(0 ${100 - sliderPosition}% 0 0)` }}
                  >
                    <img 
                      src="/porcelain-digital-future.jpg" 
                      alt="Jumeau numérique" 
                      className="comparison-image comparison-image-after"
                    />
                  </div>
                  
                  {/* Slider handle */}
                  <div 
                    className="comparison-slider-handle"
                    style={{ left: `${sliderPosition}%` }}
                  >
                    <div className="comparison-slider-button">
                      <i className="fas fa-chevron-left"></i>
                      <i className="fas fa-chevron-right"></i>
                    </div>
                  </div>
                </div>
                <p className="text-center mt-3" style={{ color: '#00D9FF', fontSize: '0.9rem', textShadow: '0 0 10px rgba(0, 217, 255, 0.3)' }}>
                  Glissez pour découvrir la transformation
                </p>
              </div>
            </div>
          </div>

          {/* Explicación del Gemelo Digital y Anti-falsificaciones */}
          <div className="row">
            <div className="col-lg-8 mx-auto">
              <div className="nft-explanation" style={{background: 'linear-gradient(135deg, rgba(27, 73, 101, 0.2) 0%, rgba(15, 47, 63, 0.2) 100%)', border: '1px solid rgba(0, 217, 255, 0.3)', borderRadius: '1rem', padding: '2rem', backdropFilter: 'blur(10px)'}}>
                <h3 className="text-center mb-4">Garantir l'Authenticité de la Porcelaine de Demain</h3>
                
                <h5 className="text-cyan mb-3"><i className="fas fa-cube me-2"></i>Qu'est-ce qu'un Jumeau Numérique ?</h5>
                <p>
                  Un jumeau numérique est une représentation virtuelle exacte et complète d'un objet physique ou d'un processus de fabrication. Pour chaque moule et chaque pièce de porcelaine créée par Filete 3D, nous générons un jumeau numérique qui capture tous les détails, les dimensions, les matériaux et l'historique de production.
                </p>

                <h5 className="text-cyan mb-3 mt-4"><i className="fas fa-link me-2"></i>Technologie Blockchain et NFT</h5>
                <p>
                  Filete 3D explore l'intégration des contrats intelligents (smart contracts) et des NFTs (Non-Fungible Tokens) comme certificats numériques d'authenticité. Ces certificats sont enregistrés de manière immuable sur la blockchain, créant un registre permanent et vérifiable de chaque création.
                </p>

                <h5 className="text-cyan mb-3 mt-4"><i className="fas fa-shield-alt me-2"></i>Système Anti-Falsifications</h5>
                <p>
                  Chaque pièce de porcelaine produite à partir de nos moules 3D reçoit un certificat NFT unique qui :
                </p>
                <ul style={{color: 'rgba(255, 255, 255, 0.85)', paddingLeft: '2rem'}}>
                  <li><strong>Certifie l'authenticité</strong> - Prouve que la pièce a été créée avec un moule Filete 3D authentifié</li>
                  <li><strong>Assure la traçabilité</strong> - Enregistre chaque étape de la production et de la distribution</li>
                  <li><strong>Protège la propriété intellectuelle</strong> - Empêche la reproduction non autorisée des designs</li>
                  <li><strong>Ajoute de la valeur</strong> - Les collectionneurs peuvent vérifier l'authenticité et l'historique complet</li>
                </ul>

                <h5 className="text-cyan mb-3 mt-4"><i className="fas fa-crown me-2"></i>Avenir de la Porcelaine Certifiée</h5>
                <p>
                  Dans un avenir proche, chaque pièce issue de Limoges pourra être accompagnée de son certificat digital, symbole d'une nouvelle ère de confiance et de valeur pour les manufactures et les collectionneurs. Ce système garantit que seules les pièces authentiques peuvent être commercialisées comme produits Filete 3D.
                </p>
              </div>
            </div>
          </div>

          <div className="text-center mt-5">
            <a href="#contact" className="btn btn-primary">Découvrir l'avenir de la porcelaine certifiée</a>
          </div>
        </div>
      </section>

      {/* Sección: Galería de Rouleaux */}
      <section id="rouleaux">
        <div className="container-fluid px-4">
          <div className="section-title">
            <h2>Rouleaux Personnalisés avec Designs à la Demande</h2>
            <p className="text-muted">Découvrez notre collection de rouleaux gravés avec des motifs uniques et personnalisés</p>
          </div>
          {/* Filtros interactivos */}
          <div className="gallery-filters mb-5">
            <button 
              className={`filter-btn ${activeFilter === 'todos' ? 'active' : ''}`}
              onClick={() => setActiveFilter('todos')}
            >
              Tous les Designs
            </button>
            <button 
              className={`filter-btn ${activeFilter === 'floral' ? 'active' : ''}`}
              onClick={() => setActiveFilter('floral')}
            >
              Motifs Floraux
            </button>
            <button 
              className={`filter-btn ${activeFilter === 'geometrique' ? 'active' : ''}`}
              onClick={() => setActiveFilter('geometrique')}
            >
              Geometrique
            </button>
            <button 
              className={`filter-btn ${activeFilter === 'abstrait' ? 'active' : ''}`}
              onClick={() => setActiveFilter('abstrait')}
            >
              Abstrait
            </button>
          </div>
          
          <div className="gallery-container">
            {rodillos.map(item => (
              <div key={item.id} className="gallery-item" data-filter="todos">
                <img src={item.src} alt={item.alt} />
                <div className="gallery-overlay">
                  <div style={{textAlign: 'center', color: 'white'}}>
                    <i className="fas fa-search" style={{fontSize: '2rem', marginBottom: '0.5rem', display: 'block'}}></i>
                    <p>Design Personnalise</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="text-center mt-5">
            <a href="#contact" className="btn btn-secondary">Créer mon rouleau personnalisé</a>
          </div>
        </div>
      </section>

      {/* Sección: Video */}
      <section className="bg-light">
        <div className="container-fluid px-4">
          <div className="section-title">
            <h2>Voir Notre Processus en Action</h2>
          </div>
          <div className="row justify-content-center">
            <div className="col-lg-8">
              <div className="video-container">
                <video controls>
                  <source src="/video.mp4" type="video/mp4" />
                  Votre navigateur ne supporte pas la lecture de vidéos HTML5.
                </video>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Sección: Confianza y Colaboración */}
      <section id="colaboracion">
        <div className="container-fluid px-4">
          <div className="section-title">
            <h2>Validé par les créateurs locaux, conçu pour l'excellence technique</h2>
          </div>
          <div className="row">
            <div className="col-md-6 col-lg-3 mb-4">
              <div className="feature-card">
                <h5 className="text-cyan">Partenaire Stratégique</h5>
                <p><a href="https://jeremyasmont.com/eclat-datelier-cafe-porcelaine/?fbclid=PAT01DUANsziJleHRuA2FlbQIxMAABp99hu-yvqW0ug3ScEKt39UHLXOVEp5LudRyp_pL8-0FOsY6cPwe9mWwjEnLO_aem_u7ik14pXYCqtN_1n0WIuxQ" target="_blank" rel="noopener noreferrer" style={{color: '#00D9FF', textDecoration: 'none'}}><strong>Éclat d'Atelier</strong></a> – Jérémy Asmont</p>
              </div>
            </div>
            <div className="col-md-6 col-lg-3 mb-4">
              <div className="feature-card">
                <h5 className="text-cyan">Qualité Certifiée</h5>
                <p>Processus validé et approuvé par les experts locaux</p>
              </div>
            </div>
            <div className="col-md-6 col-lg-3 mb-4">
              <div className="feature-card">
                <h5 className="text-cyan">Garantie de Qualité</h5>
                <p>Vérification dimensionnelle et tests de coulage</p>
              </div>
            </div>
            <div className="col-md-6 col-lg-3 mb-4">
              <div className="feature-card">
                <h5 className="text-cyan">Engagement Écologique</h5>
                <p>Réduction des déchets et optimisation des matériaux</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Sección: Contacto */}
      <section id="contact">
        <div className="container-fluid px-4">
          <div className="section-title">
            <h2>Discutons de votre prochaine collection</h2>
            <p className="text-muted">Chaque moule est une opportunité de réunir tradition et innovation</p>
          </div>
          <div className="row justify-content-center">
            <div className="col-lg-8">
              <div className="row mb-5">
                <div className="col-md-4 text-center mb-4">
                  <h5 className="text-cyan mb-3">Téléphone</h5>
                  <p><a href="tel:+330758814718" style={{color: '#00D9FF', textDecoration: 'none'}}>+33 (0)7 58 81 47 18</a></p>
                </div>
                <div className="col-md-4 text-center mb-4">
                  <h5 className="text-cyan mb-3">Email</h5>
                  <p><a href="mailto:Leonelroger003@gmail.com" style={{color: '#00D9FF', textDecoration: 'none'}}>Leonelroger003@gmail.com</a></p>
                </div>
                <div className="col-md-4 text-center mb-4">
                  <h5 className="text-cyan mb-3">LinkedIn</h5>
                  <p><a href="https://www.linkedin.com/in/leonelrogerflores/" target="_blank" rel="noopener noreferrer" style={{color: '#00D9FF', textDecoration: 'none'}}>Leonel Roger Flores</a></p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

